from .ffi import IN_PYODIDE

__all__ = ["IN_PYODIDE"]
